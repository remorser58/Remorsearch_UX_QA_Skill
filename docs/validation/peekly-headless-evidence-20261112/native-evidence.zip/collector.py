"""Collect only owned Peekly QA evidence; never run a product or overwrite artifacts."""
from pathlib import Path
import collections
import hashlib
import io
import json
import os
import stat
import subprocess
import sys
import time
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[1]
PILOT = STAGE / "ui-pilot"
OUT = ROOT / "docs/validation/peekly-headless-evidence-20261112"
REPORT = ROOT / "docs/validation/peekly-headless-results-20261112.json"

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def raw(path):
    meta = path.lstat()
    if not stat.S_ISREG(meta.st_mode) or path.resolve() != path:
        raise ValueError("Expected an owned regular file: " + str(path))
    return path.read_bytes()

def document(path):
    return json.loads(raw(path))

def canonical(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode()

def tree(path):
    return {str(p.relative_to(path)): digest(raw(p)) for p in sorted(path.rglob("*")) if p.is_file()}

def create(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as handle:
        handle.write(content)

if OUT.exists() or REPORT.exists() or (STAGE / "readback-observation.json").exists():
    raise SystemExit("Evidence destination exists; preserve it and inspect, never overwrite")

first = document(PILOT / "first-run-result.json")
assert first["execution_complete"] and first["ui_observed"]
assert first["counts"] == dict(blocked=0, failed=2, inconclusive=0, passed=2, pending=0, running=0, skipped=0)
assert not first["uncertain_dispatches"] and not first["quarantined_tasks"]
assert first["evidence_audit"]["integrity"] == "consistent"
before = tree(PILOT)
started = time.monotonic()
command = [sys.executable, "-B", str(ROOT / "benchmarks/peekly-headless-pilot/run_pilot.py"),
           "readback", "--stage", str(STAGE)]
readback = subprocess.run(command, cwd=ROOT, capture_output=True, timeout=180)
after = tree(PILOT)
readback_receipt = dict(
    schema_version="peekly-headless-readback.v1", command=command,
    returncode=readback.returncode, elapsed_seconds=round(time.monotonic() - started, 6),
    stdout_sha256=digest(readback.stdout), stderr_sha256=digest(readback.stderr),
    stdout_bytes=len(readback.stdout), stderr_bytes=len(readback.stderr),
    files_before=len(before), files_after=len(after), all_pilot_file_hashes_unchanged=before == after,
    before_manifest_sha256=digest(canonical(before)), after_manifest_sha256=digest(canonical(after)),
    result_identical_to_first_run=readback.returncode == 0 and json.loads(readback.stdout) == first,
    product_dispatch_performed=False,
)
create(STAGE / "readback-observation.json", canonical(readback_receipt))
create(STAGE / "readback-stdout.json", readback.stdout)
create(STAGE / "readback-stderr.log", readback.stderr)
assert readback_receipt["returncode"] == 0
assert readback_receipt["all_pilot_file_hashes_unchanged"]
assert readback_receipt["result_identical_to_first_run"]

members = {}
members["first-run-result.json"] = raw(PILOT / "first-run-result.json")
members["local-execution.json"] = raw(PILOT / "work/local-execution.json")
members["readback-observation.json"] = raw(STAGE / "readback-observation.json")
for name in ("prepared.json", "reviewed-plan-v2.json", "criterion-map-v2.json",
             "library-reuse-summary.json", "native-validation.json", "persona-input.json",
             "resume-prepare-requested.json"):
    members[name] = raw(PILOT / name)
members["browser-adapter-v2.json"] = raw(PILOT / "source/browser-adapter-v2.json")
for path in sorted((PILOT / "operations").glob("*.json")):
    members["operations/" + path.name] = raw(path)
for name in ("product-build-receipt.json", "product-dist-manifest.json",
             "product-source-before.json", "product-source-copy-before.json"):
    members["provenance/" + name] = raw(STAGE / name)
for name in ("generation-receipt.json", "fixture-manifest.json"):
    members["provenance/" + name] = raw(STAGE / "synthetic-fixtures" / name)
members["collector.py"] = raw(Path(__file__).resolve())

rows, images = [], {}
selected = {"T-SAMPLE": [1, 2, 4, 6], "T-RECOVER": [6, 9, 10],
            "T-LARGE-ZIP": [3, 7, 8, 10], "T-LARGE-JSON": [7]}
evidence = PILOT / "work/local-execution/run/evidence"
for task in first["tasks"]:
    task_id = task["task_id"]
    folder = evidence / task_id / "1"
    browser = folder / "scratch/browser"
    native = document(browser / "run.json")
    observation = document(folder / "observation.json")
    artifact_hashes = {a["path"]: a["sha256"] for a in task["result"]["artifacts"]}
    for artifact in task["result"]["artifacts"]:
        assert digest(raw(PILOT / "work/local-execution/run" / artifact["path"])) == artifact["sha256"]
    for path in sorted(folder.rglob("*")):
        if path.is_file():
            assert path.suffix in (".json", ".png")
            members["native/" + str(path.relative_to(evidence))] = raw(path)
    snapshots = {}
    for snapshot in native["snapshots"]:
        snap = document(browser / snapshot["path"])
        snapshots[snapshot["snapshot_id"]] = snap
        if snapshot["step_index"] in selected[task_id]:
            name = task_id + "-step-" + str(snapshot["step_index"]).zfill(3) + ".png"
            images[name] = raw(browser / snapshot["png"])
    checks = []
    for check in native["success_detail"]["criteria"]:
        snap = snapshots[check["snapshot_id"]]
        node = next(e for e in snap["elements"] if e["id"] == check["element_id"])
        checks.append(dict(
            id=check["id"], checkpoint=check["checkpoint"], result=check["result"],
            snapshot_id=check["snapshot_id"], element_id=check["element_id"],
            actual_text=node.get("text"), measured_visible=node.get("visible"),
            in_viewport=node.get("in_viewport"), occluded_fraction=node.get("occluded_fraction"),
            normalize_whitespace=check.get("normalize_whitespace", False),
        ))
    uploads = [dict(step_index=step["step_index"], file_selection=step.get("file_selection"))
               for step in native["steps"] if step["action"]["action"] == "upload"]
    assert all(row["file_selection"] for row in uploads)
    rows.append(dict(
        task_id=task_id, persona=task["binding"], operation_id=task["operation_id"],
        status=task["status"], attempts=task["attempts"], native_status=native["status"],
        native_run_sha256=digest(raw(browser / "run.json")),
        observation_sha256=digest(raw(folder / "observation.json")),
        action_count=len(native["steps"]), action_results=dict(collections.Counter(s["result"] for s in native["steps"])),
        check_counts=dict(collections.Counter(c["result"] for c in checks)), checks=checks, uploads=uploads,
        owned_execution=native["owned_execution"], owned_browser_activity=native["owned_browser_activity"],
        browser_cleanup_confirmed=observation["browser_response"]["cleanup_confirmed"],
        controller_diagnostic=observation["diagnostic"], started_at=native["started_at"], ended_at=native["ended_at"],
        console_errors=native["console_errors"], screen_url=native["surface"].get("url"),
        pngs=[dict(path=name, sha256=digest(content)) for name, content in images.items() if name.startswith(task_id + "-")],
    ))
assert sum(r["action_count"] for r in rows) == 37
assert sum(r["check_counts"].get("pass", 0) for r in rows) == 33
assert sum(r["check_counts"].get("fail", 0) for r in rows) == 4
assert all(r["browser_cleanup_confirmed"] and r["controller_diagnostic"]["returncode"] == 0 for r in rows)

manifest = {name: dict(size_bytes=len(content), sha256=digest(content)) for name, content in sorted(members.items())}
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, content in sorted(members.items()):
        entry = zipfile.ZipInfo(name, date_time=(2026, 11, 12, 0, 0, 0))
        entry.compress_type = zipfile.ZIP_DEFLATED
        entry.external_attr = 0o100644 << 16
        archive.writestr(entry, content)
archive_bytes = buffer.getvalue()
with zipfile.ZipFile(io.BytesIO(archive_bytes)) as archive:
    assert archive.testzip() is None
    assert all(digest(archive.read(name)) == meta["sha256"] for name, meta in manifest.items())
OUT.mkdir()
create(OUT / "native-evidence.zip", archive_bytes)
create(OUT / "archive-manifest.json", canonical(manifest))
for name, content in images.items():
    create(OUT / name, content)
build = document(STAGE / "product-build-receipt.json")
release = document(STAGE / "release-owned-spa/validation.json")
report = dict(
    schema_version="peekly-headless-validation.v1",
    base_commit="7359fb6c8c770601598d431b92d350bda20096d9",
    protocol_commit="28160d29f9f5b07b8b97c86c66034d67588fbe26",
    actual_product_code_executed=True, actual_isolated_browser_executed=True,
    synthetic_product_html=False, product_source_modified=False,
    synthetic_personas=True, persona_provenance_mode="prd_hypothesis",
    saved_profiles=4, executed_profiles=3, new_public_research_sources=0, real_participants=0,
    real_user_evidence=False, persona_effectiveness_validated=False, product_ready=False,
    task_scope_passed=first["task_scope_passed"], counts=first["counts"],
    native_check_counts=dict(passed=33, failed=4, unobserved=0), native_action_count=37,
    evidence_audit=first["evidence_audit"], coverage=first["coverage"], tasks=rows,
    build=dict(original=build["original"], head=build["original_git_before"]["head"],
               source_manifest_sha256="dd057f188c7f222d879956506dc314bfbff373d7bd4331d628d2dbebee62c838",
               build_receipt_sha256=digest(raw(STAGE / "product-build-receipt.json")),
               dist_content_sha256=build["dist_content_sha256"], dist_file_count=build["dist_file_count"],
               dist_file_bytes=build["dist_file_bytes"], preservation_at_build=build["preservation"]),
    prepared_sha256=digest(raw(PILOT / "prepared.json")), readback=readback_receipt,
    first_release=dict(ready=release["ready"], checks=release["checks"],
                       report_sha256=digest(raw(STAGE / "release-owned-spa/validation.json"))),
    archived_evidence=dict(
        path=OUT.name + "/native-evidence.zip", size_bytes=len(archive_bytes), sha256=digest(archive_bytes),
        members=len(members), manifest_path=OUT.name + "/archive-manifest.json",
        manifest_sha256=digest(canonical(manifest)), original_evidence_root=str(evidence),
        original_evidence_files=131, original_native_png_files=82, named_png_copies=len(images),
        product_sources_dependencies_and_synthetic_input_files_included=False,
    ),
    report_boundary_notes=[
        "Original raw first-run report is immutable. Its legacy generic network limitation predates the subsequent explanatory-text correction; actual Worker policy is in each owned_execution record.",
        "The archive contains complete native JSON and PNG evidence plus provenance metadata; it excludes product source, dependencies, real accounts and actual user files.",
        "UI success checks cover displayed counts, titles and limitation text; they do not prove every list row, complete storage byte identity, human comprehension, or UX effectiveness.",
        "Both large inputs were rejected in UI. An original RangeError or exception stack was not captured; source-based aggregation analysis is an inference.",
        "The 5000-row synthetic control was generated but not executed through UI.",
    ],
)
create(REPORT, canonical(report))
print(json.dumps(dict(report=str(REPORT), archive_bytes=len(archive_bytes), archive_members=len(members),
                      pngs=len(images), readback_unchanged=True, counts=first["counts"]), ensure_ascii=False))

