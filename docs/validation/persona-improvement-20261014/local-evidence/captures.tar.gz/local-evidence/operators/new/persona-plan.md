# 페르소나 구성 근거 (AU-delivery-comparison-20261014)

예산 4개. 세그먼트 비중은 배분에만 쓰며 실제 사용자 비율을 뜻하지 않습니다. 각 프로필은 시험 조건이지 평균 사용자가 아닙니다.

| 세그먼트 | 우선순위 | 가중치 | 프로필 수 |
|---|---|---|---|
| First-use commuter ordering one-handed (SEG-commuter) | primary | 0.5 | 2 |
| Caregiver preserving allergy requests across interruptions (SEG-caregiver) | primary | 0.5 | 2 |

| ID | 설명 | 기기 | 이유 | 근거 |
|---|---|---|---|---|
| AP-01 | [First-use commuter ordering one-handed] 30s · 오른손잡이 · 오른손 한 손 파지 · 대중교통 이동 중 · 첫 사용 | galaxy-s24 | segment SEG-commuter base profile (a base for variation, not an average user): 30s, galaxy-s24, one_hand_right | SRC-BRIEF |
| AP-02 | [Caregiver preserving allergy requests across interruptions] 40s · 오른손잡이 · 오른손 한 손 파지 | galaxy-s24 | segment SEG-caregiver base profile (a base for variation, not an average user): 40s, galaxy-s24, one_hand_right | SRC-BRIEF |
| AP-03 | [First-use commuter ordering one-handed] 30s · 왼손잡이 · 왼손 한 손 파지 · 대중교통 이동 중 · 첫 사용 | galaxy-s24 | segment SEG-commuter base profile (a base for variation, not an average user): 30s, galaxy-s24, one_hand_left; varies one facet: left-hand mirror (left-handed share 8%; left-thumb one-handed use is common) | SRC-BRIEF |
| AP-04 | [Caregiver preserving allergy requests across interruptions] 40s · 왼손잡이 · 왼손 한 손 파지 | galaxy-s24 | segment SEG-caregiver base profile (a base for variation, not an average user): 40s, galaxy-s24, one_hand_left; varies one facet: left-hand mirror (left-handed share 6%; left-thumb one-handed use is common) | SRC-BRIEF |
