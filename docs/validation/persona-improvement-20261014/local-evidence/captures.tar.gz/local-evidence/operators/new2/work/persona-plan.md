# 페르소나 구성 근거 (AU-delivery-comparison-20261014)

예산 2개. 세그먼트 비중은 배분에만 쓰며 실제 사용자 비율을 뜻하지 않습니다. 각 프로필은 시험 조건이지 평균 사용자가 아닙니다.

| 세그먼트 | 우선순위 | 가중치 | 프로필 수 |
|---|---|---|---|
| First-use commuter ordering one-handed (SEG-commuter) | primary | 0.5 | 1 |
| Caregiver preserving allergy requests across interruptions (SEG-caregiver) | primary | 0.5 | 1 |

| ID | 설명 | 기기 | 이유 | 근거 |
|---|---|---|---|---|
| AP-01 | [First-use commuter ordering one-handed] 30s · 오른손잡이 · 오른손 한 손 파지 · 대중교통 이동 중 · 첫 사용 | galaxy-s24 | segment SEG-commuter base profile (a base for variation, not an average user): 30s, galaxy-s24, one_hand_right | SRC-BRIEF |
| AP-02 | [Caregiver preserving allergy requests across interruptions] 40s · 오른손잡이 · 오른손 한 손 파지 | galaxy-s24 | segment SEG-caregiver base profile (a base for variation, not an average user): 40s, galaxy-s24, one_hand_right | SRC-BRIEF |

## 예산 밖이라 시험하지 않은 조건

- First-use commuter ordering one-handed: inclusive floor left_hand (touch) — budget exhausted
- First-use commuter ordering one-handed: left-hand mirror (left-handed share 8%; left-thumb one-handed use is common)
- Caregiver preserving allergy requests across interruptions: left-hand mirror (left-handed share 6%; left-thumb one-handed use is common)
