# 인간공학 페르소나 스웜 QA 보고서

## 1. 범위와 증거 경계

- 실행(run) 4건, 시뮬레이션 프로필 2개. 문제 단위 13건 (P0 0 · P1 4 · P2 5 · P3 4), 요소별 발견 21건 (P0 0 · P1 4 · P2 7 · P3 10).
- 문제 단위는 같은 시나리오·같은 체크·같은 차이 조건의 발견을 하나로 묶은 것입니다(예: 한 화면의 작은 본문 글자 여러 개 = 1건).
- 모든 조작은 드라이버가 실제 화면(브라우저/기기)에서 수행한 기록을 분석했습니다. 인간공학 수치는 결정론적 모델이 계산했고, LLM 페르소나가 연기하지 않았습니다.
- 'k/n 시뮬레이션 프로필'은 **커버리지**이며 실제 사용자 비율(유병률·선호)을 뜻하지 않습니다.
- 실측(observed)과 모델 예측(inferred)을 분리해 표기했습니다. 모델 예측은 실제 사용자 테스트로 확인해야 하는 가설입니다.
- 엄지 도달 모델은 보정 전 휴리스틱(thumb-reach-v3-uncalibrated)이므로 단독으로 P2를 넘기지 않습니다.

- AP-01-page1 S-AP-01-page1-001 #grp-extra-cheese: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-001 #grp-extra-cola: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-001 #grp-extra-mustard: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-001 #grp-extra-radish: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-001 #grp-sauce-garlic-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-01-page1 S-AP-01-page1-001 #grp-sauce-hot-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-01-page1 S-AP-01-page1-002 #grp-extra-cheese: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-002 #grp-extra-cola: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-002 #grp-extra-mustard: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-002 #grp-extra-radish: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-002 #grp-sauce-garlic-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-01-page1 S-AP-01-page1-002 #grp-sauce-hot-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-01-page1 S-AP-01-page1-003 #grp-extra-cheese: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-003 #grp-extra-cola: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-003 #grp-extra-mustard: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-003 #grp-extra-radish: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-003 #grp-sauce-garlic-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-01-page1 S-AP-01-page1-003 #grp-sauce-hot-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-01-page1 S-AP-01-page1-004 #grp-extra-cheese: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-004 #grp-extra-cola: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-004 #grp-extra-mustard: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-004 #grp-extra-radish: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-004 #grp-sauce-garlic-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-01-page1 S-AP-01-page1-004 #grp-sauce-hot-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-01-page1 S-AP-01-page1-004 #opt-base: PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page1 S-AP-01-page1-005 #grp-extra-cheese: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-005 #grp-extra-cola: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-005 #grp-extra-mustard: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-005 #grp-extra-radish: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-005 #grp-sauce-garlic-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-01-page1 S-AP-01-page1-005 #grp-sauce-hot-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-01-page1 S-AP-01-page1-005 #opt-base: PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page1 S-AP-01-page1-006 #grp-extra-cheese: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-006 #grp-extra-cola: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-006 #grp-extra-mustard: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-006 #grp-extra-radish: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-006 #grp-sauce-garlic-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-01-page1 S-AP-01-page1-006 #grp-sauce-hot-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-01-page1 S-AP-01-page1-006 #opt-base: PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page1 S-AP-01-page1-007 #grp-extra-cheese: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-007 #grp-extra-cola: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-007 #grp-extra-mustard: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-007 #grp-extra-radish: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-007 #grp-sauce-garlic-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-01-page1 S-AP-01-page1-007 #grp-sauce-hot-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-01-page1 S-AP-01-page1-007 #opt-base: PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page1 S-AP-01-page1-008 #grp-extra-cheese: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-008 #grp-extra-cola: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-008 #grp-extra-mustard: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-008 #grp-extra-radish: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-008 #grp-sauce-garlic-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-01-page1 S-AP-01-page1-008 #grp-sauce-hot-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-01-page1 S-AP-01-page1-008 #opt-base: PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page1 S-AP-01-page1-009 #grp-extra-cheese: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-009 #grp-extra-cola: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-009 #grp-extra-mustard: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-009 #grp-extra-radish: PC-02/PC-03 paint unverified (native_appearance)
- AP-01-page1 S-AP-01-page1-009 #grp-sauce-garlic-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-01-page1 S-AP-01-page1-009 #grp-sauce-hot-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-01-page1 S-AP-01-page1-009 #opt-base: PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page1 S-AP-01-page1-012 #qty-1-inc: PC-02/PC-03 paint unverified (pseudo_paint)
- AP-01-page1 S-AP-01-page1-013 #qty-1-inc: PC-02/PC-03 paint unverified (pseudo_paint)
- AP-01-page1 S-AP-01-page1-014 #qty-1-dec: PC-02/PC-03 paint unverified (pseudo_paint)
- AP-01-page1 S-AP-01-page1-014 #qty-1-inc: PC-02/PC-03 paint unverified (pseudo_paint)
- AP-01-page1 S-AP-01-page1-015 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-016 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-017 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-018 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-019 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-020 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-021 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-022 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-023 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-024 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-025 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-026 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-027 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-028 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-029 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-030 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-031 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-032 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-033 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-034 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-035 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-036 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-037 #addr-detail-error: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-037 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-037 #rider > label:nth-of-type(2) > span:nth-of-type(2): PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page1 S-AP-01-page1-038 #addr-detail-error: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-038 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-038 #rider > label:nth-of-type(2) > span:nth-of-type(2): PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page1 S-AP-01-page1-039 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-040 #track-eta: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-040 #track-headline: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-040 #track-steps-1 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-01-page1 S-AP-01-page1-040 #track-steps-2 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-01-page1 S-AP-01-page1-040 #track-steps-3 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-01-page1 S-AP-01-page1-040 #track-steps-4 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-01-page1 S-AP-01-page1-040 #track-steps: PC-02/PC-03 paint unverified (pseudo_paint, unsupported_effect)
- AP-01-page1 S-AP-01-page1-041 #track-eta: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-041 #track-headline: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page1 S-AP-01-page1-041 #track-steps-1 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-01-page1 S-AP-01-page1-041 #track-steps-2 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-01-page1 S-AP-01-page1-041 #track-steps-3 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-01-page1 S-AP-01-page1-041 #track-steps-4 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-01-page1 S-AP-01-page1-041 #track-steps: PC-02/PC-03 paint unverified (pseudo_paint, unsupported_effect)
- AP-01-page2 S-AP-01-page2-001 #grp-sauce-garlic-label > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-001 #grp-sauce-garlic-label > span > span:nth-of-type(2): PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-002 #grp-sauce-garlic-label > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-002 #grp-sauce-garlic-label > span > span:nth-of-type(2): PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-003 #grp-sauce-garlic-label > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-003 #grp-sauce-garlic-label > span > span:nth-of-type(2): PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-004 #grp-extra-mustard-name: PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-004 #grp-extra-mustard-price: PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-005 #grp-extra-mustard-name: PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-005 #grp-extra-mustard-price: PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-006 #grp-extra-mustard-name: PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-006 #grp-extra-mustard-price: PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-007 #add-to-cart-error: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-007 #grp-sauce-error: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-008 #add-to-cart-error: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-008 #grp-sauce-error: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-010 #cart-btn-count: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-010 #menu-garlic: PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-010 #sec-chicken-title: PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-011 #cart-btn-count: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-011 #menu-garlic: PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-011 #sec-chicken-title: PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-012 #qty-1-inc: PC-02/PC-03 paint unverified (pseudo_paint)
- AP-01-page2 S-AP-01-page2-013 #qty-1-inc: PC-02/PC-03 paint unverified (pseudo_paint)
- AP-01-page2 S-AP-01-page2-014 #qty-1-dec: PC-02/PC-03 paint unverified (pseudo_paint)
- AP-01-page2 S-AP-01-page2-014 #qty-1-inc: PC-02/PC-03 paint unverified (pseudo_paint)
- AP-01-page2 S-AP-01-page2-015 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-016 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-017 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-018 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-019 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-020 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-021 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-021 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-022 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-022 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-023 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-023 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-024 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-024 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-025 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-025 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-026 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-026 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-027 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-027 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-028 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-028 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-029 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-029 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-030 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-030 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-031 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-031 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-032 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-032 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-033 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-033 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-034 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-035 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-036 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-037 #addr-detail-error: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-037 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-037 #rider > label:nth-of-type(2) > span:nth-of-type(2): PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-038 #addr-detail-error: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-038 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-038 #rider > label:nth-of-type(2) > span:nth-of-type(2): PC-02/PC-03 paint unverified (occluded_paint)
- AP-01-page2 S-AP-01-page2-039 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-040 #track-eta: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-040 #track-headline: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-040 #track-steps-1 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-01-page2 S-AP-01-page2-040 #track-steps-3 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-01-page2 S-AP-01-page2-040 #track-steps-4 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-01-page2 S-AP-01-page2-040 #track-steps: PC-02/PC-03 paint unverified (pseudo_paint, unsupported_effect)
- AP-01-page2 S-AP-01-page2-041 #track-eta: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-041 #track-headline: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-01-page2 S-AP-01-page2-041 #track-steps-1 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-01-page2 S-AP-01-page2-041 #track-steps-3 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-01-page2 S-AP-01-page2-041 #track-steps-4 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-01-page2 S-AP-01-page2-041 #track-steps: PC-02/PC-03 paint unverified (pseudo_paint, unsupported_effect)
- AP-03-page1 S-AP-03-page1-001 #grp-extra-cheese: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-001 #grp-extra-cola: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-001 #grp-extra-mustard: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-001 #grp-extra-radish: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-001 #grp-sauce-garlic-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-03-page1 S-AP-03-page1-001 #grp-sauce-hot-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-03-page1 S-AP-03-page1-002 #grp-extra-cheese: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-002 #grp-extra-cola: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-002 #grp-extra-mustard: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-002 #grp-extra-radish: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-002 #grp-sauce-garlic-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-03-page1 S-AP-03-page1-002 #grp-sauce-hot-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-03-page1 S-AP-03-page1-003 #grp-extra-cheese: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-003 #grp-extra-cola: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-003 #grp-extra-mustard: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-003 #grp-extra-radish: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-003 #grp-sauce-garlic-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-03-page1 S-AP-03-page1-003 #grp-sauce-hot-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-03-page1 S-AP-03-page1-004 #grp-extra-cheese: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-004 #grp-extra-cola: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-004 #grp-extra-mustard: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-004 #grp-extra-radish: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-004 #grp-sauce-garlic-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-03-page1 S-AP-03-page1-004 #grp-sauce-hot-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-03-page1 S-AP-03-page1-004 #opt-base: PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page1 S-AP-03-page1-005 #grp-extra-cheese: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-005 #grp-extra-cola: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-005 #grp-extra-mustard: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-005 #grp-extra-radish: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-005 #grp-sauce-garlic-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-03-page1 S-AP-03-page1-005 #grp-sauce-hot-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-03-page1 S-AP-03-page1-005 #opt-base: PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page1 S-AP-03-page1-006 #grp-extra-cheese: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-006 #grp-extra-cola: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-006 #grp-extra-mustard: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-006 #grp-extra-radish: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-006 #grp-sauce-garlic-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-03-page1 S-AP-03-page1-006 #grp-sauce-hot-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-03-page1 S-AP-03-page1-006 #opt-base: PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page1 S-AP-03-page1-007 #grp-extra-cheese: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-007 #grp-extra-cola: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-007 #grp-extra-mustard: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-007 #grp-extra-radish: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-007 #grp-sauce-garlic-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-03-page1 S-AP-03-page1-007 #grp-sauce-hot-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-03-page1 S-AP-03-page1-007 #opt-base: PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page1 S-AP-03-page1-008 #grp-extra-cheese: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-008 #grp-extra-cola: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-008 #grp-extra-mustard: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-008 #grp-extra-radish: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-008 #grp-sauce-garlic-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-03-page1 S-AP-03-page1-008 #grp-sauce-hot-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-03-page1 S-AP-03-page1-008 #opt-base: PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page1 S-AP-03-page1-009 #grp-extra-cheese: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-009 #grp-extra-cola: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-009 #grp-extra-mustard: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-009 #grp-extra-radish: PC-02/PC-03 paint unverified (native_appearance)
- AP-03-page1 S-AP-03-page1-009 #grp-sauce-garlic-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-03-page1 S-AP-03-page1-009 #grp-sauce-hot-label > span: PC-02/PC-03 paint unverified (clipped_paint)
- AP-03-page1 S-AP-03-page1-009 #opt-base: PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page1 S-AP-03-page1-012 #qty-1-inc: PC-02/PC-03 paint unverified (pseudo_paint)
- AP-03-page1 S-AP-03-page1-013 #qty-1-inc: PC-02/PC-03 paint unverified (pseudo_paint)
- AP-03-page1 S-AP-03-page1-014 #qty-1-dec: PC-02/PC-03 paint unverified (pseudo_paint)
- AP-03-page1 S-AP-03-page1-014 #qty-1-inc: PC-02/PC-03 paint unverified (pseudo_paint)
- AP-03-page1 S-AP-03-page1-015 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-016 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-017 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-018 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-019 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-020 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-021 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-022 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-023 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-024 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-025 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-026 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-027 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-028 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-029 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-030 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-031 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-032 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-033 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-034 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-035 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-036 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-037 #addr-detail-error: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-037 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-037 #rider > label:nth-of-type(2) > span:nth-of-type(2): PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page1 S-AP-03-page1-038 #addr-detail-error: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-038 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-038 #rider > label:nth-of-type(2) > span:nth-of-type(2): PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page1 S-AP-03-page1-039 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-040 #track-eta: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-040 #track-headline: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-040 #track-steps-1 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-03-page1 S-AP-03-page1-040 #track-steps-2 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-03-page1 S-AP-03-page1-040 #track-steps-3 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-03-page1 S-AP-03-page1-040 #track-steps-4 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-03-page1 S-AP-03-page1-040 #track-steps: PC-02/PC-03 paint unverified (pseudo_paint, unsupported_effect)
- AP-03-page1 S-AP-03-page1-041 #track-eta: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-041 #track-headline: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page1 S-AP-03-page1-041 #track-steps-1 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-03-page1 S-AP-03-page1-041 #track-steps-2 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-03-page1 S-AP-03-page1-041 #track-steps-3 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-03-page1 S-AP-03-page1-041 #track-steps-4 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-03-page1 S-AP-03-page1-041 #track-steps: PC-02/PC-03 paint unverified (pseudo_paint, unsupported_effect)
- AP-03-page2 S-AP-03-page2-001 #grp-sauce-garlic-label > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-001 #grp-sauce-garlic-label > span > span:nth-of-type(2): PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-002 #grp-sauce-garlic-label > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-002 #grp-sauce-garlic-label > span > span:nth-of-type(2): PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-003 #grp-sauce-garlic-label > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-003 #grp-sauce-garlic-label > span > span:nth-of-type(2): PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-004 #grp-extra-mustard-name: PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-004 #grp-extra-mustard-price: PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-005 #grp-extra-mustard-name: PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-005 #grp-extra-mustard-price: PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-006 #grp-extra-mustard-name: PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-006 #grp-extra-mustard-price: PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-007 #add-to-cart-error: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-007 #grp-sauce-error: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-008 #add-to-cart-error: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-008 #grp-sauce-error: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-010 #cart-btn-count: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-010 #menu-garlic: PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-010 #sec-chicken-title: PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-011 #cart-btn-count: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-011 #menu-garlic: PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-011 #sec-chicken-title: PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-012 #qty-1-inc: PC-02/PC-03 paint unverified (pseudo_paint)
- AP-03-page2 S-AP-03-page2-013 #qty-1-inc: PC-02/PC-03 paint unverified (pseudo_paint)
- AP-03-page2 S-AP-03-page2-014 #qty-1-dec: PC-02/PC-03 paint unverified (pseudo_paint)
- AP-03-page2 S-AP-03-page2-014 #qty-1-inc: PC-02/PC-03 paint unverified (pseudo_paint)
- AP-03-page2 S-AP-03-page2-015 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-016 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-017 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-018 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-019 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-020 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-021 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-021 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-022 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-022 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-023 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-023 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-024 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-024 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-025 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-025 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-026 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-026 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-027 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-027 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-028 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-028 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-029 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-029 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-030 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-030 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-031 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-031 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-032 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-032 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-033 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-033 #paymethod > label:nth-of-type(3) > span > span:nth-of-type(1): PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-034 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-035 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-036 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-037 #addr-detail-error: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-037 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-037 #rider > label:nth-of-type(2) > span:nth-of-type(2): PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-038 #addr-detail-error: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-038 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-038 #rider > label:nth-of-type(2) > span:nth-of-type(2): PC-02/PC-03 paint unverified (occluded_paint)
- AP-03-page2 S-AP-03-page2-039 #coupon-msg: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-040 #track-eta: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-040 #track-headline: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-040 #track-steps-1 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-03-page2 S-AP-03-page2-040 #track-steps-3 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-03-page2 S-AP-03-page2-040 #track-steps-4 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-03-page2 S-AP-03-page2-040 #track-steps: PC-02/PC-03 paint unverified (pseudo_paint, unsupported_effect)
- AP-03-page2 S-AP-03-page2-041 #track-eta: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-041 #track-headline: PC-02/PC-03 paint unverified (no_graphic_paint)
- AP-03-page2 S-AP-03-page2-041 #track-steps-1 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-03-page2 S-AP-03-page2-041 #track-steps-3 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-03-page2 S-AP-03-page2-041 #track-steps-4 > span:nth-of-type(3): PC-02/PC-03 paint unverified (unsupported_effect)
- AP-03-page2 S-AP-03-page2-041 #track-steps: PC-02/PC-03 paint unverified (pseudo_paint, unsupported_effect)

## 2. 실행 목록

| run | 시나리오 | 기기 | 실행 상태 | 과업 성공 | 평가 프로필 |
|---|---|---|---|---|---|
| AP-01-page1 | SC-d2-delivery-b | galaxy-s24 (portrait) | completed | True | AP-01 |
| AP-01-page2 | SC-d2-delivery-a | galaxy-s24 (portrait) | completed | True | AP-01 |
| AP-03-page1 | SC-d2-delivery-b | galaxy-s24 (portrait) | completed | True | AP-03 |
| AP-03-page2 | SC-d2-delivery-a | galaxy-s24 (portrait) | completed | True | AP-03 |

## 3. 시뮬레이션 프로필 (시나리오 가정)

| ID | 설명 | 기기 | 표본 방식 |
|---|---|---|---|
| AP-01 | [First-use commuter ordering one-handed] 30s · 오른손잡이 · 오른손 한 손 파지 · 대중교통 이동 중 · 첫 사용 | galaxy-s24 | audience_composed |
| AP-03 | [First-use commuter ordering one-handed] 30s · 왼손잡이 · 왼손 한 손 파지 · 대중교통 이동 중 · 첫 사용 | galaxy-s24 | audience_composed |

- 테스트한 기기: galaxy-s24
- 프로필은 대상 사용자 리서치(ergo-audience.v1)의 세그먼트에서 구성했습니다. 세그먼트 비중은 배분에만 썼고 실제 사용자 비율이 아닙니다.
  - AP-01: First-use commuter ordering one-handed — segment SEG-commuter base profile (a base for variation, not an average user): 30s, galaxy-s24, one_hand_right
  - AP-03: First-use commuter ordering one-handed — segment SEG-commuter base profile (a base for variation, not an average user): 30s, galaxy-s24, one_hand_left; varies one facet: left-hand mirror (left-handed share 8%; left-thumb one-handed use is common)
- 페르소나 데이터셋에 없는 인간공학 속성(손잡이·파지·손 크기·시력·운동·기기)은 모두 시나리오 가정입니다.

## 4. 문제 단위 (분류·수정 우선순위용)

| ID | 심각도 | 체크 | 시나리오 | 조건 | 요소 수 | 발견 ID |
|---|---|---|---|---|---|---|
| EU-001 | P1 | PT-02 터치 타깃 물리 크기가 플랫폼 권장치 미만 | SC-d2-delivery-b | all tested profiles | 4 | EF-001, EF-029, EF-031, EF-032 |
| EU-002 | P1 | PT-04 예측 오터치 확률이 높은 조작 대상 | SC-d2-delivery-b | all tested profiles | 3 | EF-002, EF-030, EF-033 |
| EU-003 | P1 | SM-01 이름 없는 조작 요소(스크린리더·음성 제어로 식별 불가) | SC-d2-delivery-b | all tested profiles | 2 | EF-004, EF-011 |
| EU-004 | P1 | SM-08 과업이 누른 조작 요소에 역할이 없고 키보드로 갈 수 없음 | SC-d2-delivery-b | all tested profiles | 1 | EF-003 |
| EU-005 | P2 | GZ-02 조작 지점에서 멀리 뜨는 피드백/오류 메시지(변화맹 위험) | SC-d2-delivery-a | grip=one_hand_left;handedness=left | 1 | EF-005 |
| EU-006 | P2 | GZ-02 조작 지점에서 멀리 뜨는 피드백/오류 메시지(변화맹 위험) | SC-d2-delivery-b | grip=one_hand_left;handedness=left | 1 | EF-006 |
| EU-007 | P2 | LY-01 상자에 잘린 텍스트 | SC-d2-delivery-b | all tested profiles | 2 | EF-007, EF-008 |
| EU-008 | P2 | RH-01 한 손 엄지 도달이 어려운 위치의 조작 대상 | SC-d2-delivery-b | all tested profiles | 1 | EF-009 |
| EU-009 | P2 | SM-02 보이는 레이블이 접근 가능한 이름에 없음(음성 제어 불일치) | SC-d2-delivery-b | all tested profiles | 1 | EF-010 |
| EU-010 | P3 | PT-02 터치 타깃 물리 크기가 플랫폼 권장치 미만 | SC-d2-delivery-a | all tested profiles | 2 | EF-026, EF-027 |
| EU-011 | P3 | PT-04 예측 오터치 확률이 높은 조작 대상 | SC-d2-delivery-a | all tested profiles | 1 | EF-028 |
| EU-012 | P3 | RH-01 한 손 엄지 도달이 어려운 위치의 조작 대상 | SC-d2-delivery-a | grip=one_hand_left;handedness=left | 1 | EF-034 |
| EU-013 | P3 | RH-01 한 손 엄지 도달이 어려운 위치의 조작 대상 | SC-d2-delivery-b | grip=one_hand_left;handedness=left | 1 | EF-035 |

### 요소별 발견 요약

| ID | 심각도 | 범주 | 근거 | 대상 | 커버리지 | 차이 조건 |
|---|---|---|---|---|---|---|
| EF-001 | P1 | pointing | 실측 | #grp-extra-cola / 콜라 1.25L +2,500원 | 2/2 simulated profiles | - |
| EF-002 | P1 | pointing | 모델 예측 | #grp-extra-cola / 콜라 1.25L +2,500원 | 2/2 simulated profiles | - |
| EF-003 | P1 | semantics | 실측 | #grp-part-boneless / 순살 +2,000원 | profile-independent | - |
| EF-004 | P1 | semantics | 실측 | #qty-1-inc /  | profile-independent | - |
| EF-005 | P2 | gaze | 모델 예측 | #coupon-msg / ‘HANKI5000’은(는) 없는 쿠폰 코드예요. 철자를 확인 | 1/2 simulated profiles | handedness=left, grip=one_hand_left |
| EF-006 | P2 | gaze | 모델 예측 | #coupon-msg / 쿠폰을 적용할 수 없습니다. (CPN-4003) | 1/2 simulated profiles | handedness=left, grip=one_hand_left |
| EF-007 | P2 | layout | 실측 | #grp-sauce-garlic-label > span / 간장마늘 +1,000원 | profile-independent | - |
| EF-008 | P2 | layout | 실측 | #grp-sauce-hot-label > span / 매운 양념 +500원 | profile-independent | - |
| EF-009 | P2 | reach | 모델 예측 | #cart-btn / 장바구니, 비어 있음 | 2/2 simulated profiles | - |
| EF-010 | P2 | semantics | 실측 | #cart-btn / 장바구니, 1개 담김 | profile-independent | - |
| EF-011 | P2 | semantics | 실측 | #qty-1-dec /  | profile-independent | - |
| EF-026 | P3 | pointing | 실측 | #line-1-del / 반반치킨 삭제 | 2/2 simulated profiles | - |
| EF-027 | P3 | pointing | 실측 | #qty-1-inc / 반반치킨 수량 늘리기 | 2/2 simulated profiles | - |
| EF-028 | P3 | pointing | 모델 예측 | #qty-1-inc / 반반치킨 수량 늘리기 | 2/2 simulated profiles | - |
| EF-029 | P3 | pointing | 실측 | #cart-btn / 장바구니, 비어 있음 | 2/2 simulated profiles | - |
| EF-030 | P3 | pointing | 모델 예측 | #cart-btn / 장바구니, 비어 있음 | 2/2 simulated profiles | - |
| EF-031 | P3 | pointing | 실측 | #line-1-del / 반반치킨 삭제 | 2/2 simulated profiles | - |
| EF-032 | P3 | pointing | 실측 | #qty-1-inc /  | 2/2 simulated profiles | - |
| EF-033 | P3 | pointing | 모델 예측 | #qty-1-inc /  | 2/2 simulated profiles | - |
| EF-034 | P3 | reach | 모델 예측 | #qty-1-inc / 반반치킨 수량 늘리기 | 1/2 simulated profiles | handedness=left, grip=one_hand_left |
| EF-035 | P3 | reach | 모델 예측 | #qty-1-inc /  | 1/2 simulated profiles | handedness=left, grip=one_hand_left |

### 세그먼트별 발견

| 세그먼트 | P0 | P1 | P2 | P3 | 이 세그먼트에서만 발생 |
|---|---|---|---|---|---|
| First-use commuter ordering one-handed (SEG-commuter) | 0 | 4 | 7 | 10 | EF-001, EF-002, EF-003, EF-004, EF-005, EF-006, EF-007, EF-008 … |

## 5. 발견 상세

### EF-001 [P1] 터치 타깃 물리 크기가 플랫폼 권장치 미만

- 체크: `PT-02` · 범주: pointing · 근거: 실측(화면에서 측정, observed)
- 시나리오: `SC-d2-delivery-b` · 대상: `#grp-extra-cola|콜라 1.25L +2,500원`
- 관찰: '콜라 1.25L +2,500원' 물리 크기 3.3×3.3mm (기준 4.4mm 이상).
- 측정: target_mm=[3.3, 3.3] mm (기준 >= 4.4)
- 커버리지: 2/2 simulated profiles (coverage, not prevalence) — 발생 AP-01, AP-03
- 영향 세그먼트(구성 프로필 기준, 비율 아님): SEG-commuter
- 권장 수정(visual): AP-01, AP-03 조건: 기록된 타깃 상자를 기기 카탈로그 밀도로 환산하면 3.3×3.3mm(짧은 변 3.3mm)이며 플랫폼 최소 하한(iOS HIG 28pt 유래) 4.4mm에 미달했습니다. 짧은 변을 4.4mm 이상으로 키우세요(현재 3.3mm, 1.1mm 이상 증가). mm 값은 카탈로그 밀도로 환산한 추정치이며 44pt/48dp와 정확히 일치하는 단위 환산이 아니므로 플랫폼 도구에서는 pt/dp 권장을 그대로 적용하세요. 터치 타깃을 44pt/48dp(약 7–9mm) 이상으로 키우세요.
- 근거 문헌: REF-apple-hig-44pt, REF-material-48dp, REF-parhi2006
- 증거 ID: OB-AP-01-page1-AP-01-0020, OB-AP-03-page1-AP-03-0020

### EF-002 [P1] 예측 오터치 확률이 높은 조작 대상

- 체크: `PT-04` · 범주: pointing · 근거: 모델 예측(inferred) · 모델: `bi-zhai-2016-dual-gaussian`
- 시나리오: `SC-d2-delivery-b` · 대상: `#grp-extra-cola|콜라 1.25L +2,500원`
- 관찰: '콜라 1.25L +2,500원' 예측 오터치 확률 72.3% (기준 인구 34.8%, σ배수 1.82, 3.3×3.3mm).
- 측정: miss_probability=0.7226 probability (기준 < 0.03)
- 커버리지: 2/2 simulated profiles (coverage, not prevalence) — 발생 AP-01, AP-03
- 영향 세그먼트(구성 프로필 기준, 비율 아님): SEG-commuter
- 권장 수정(visual): 타깃 크기와 간격을 키우고, 이동 중·손떨림 사용자를 위한 여유 영역(hit slop)을 두세요.
- 근거 문헌: REF-bi-zhai2013, REF-henze2011, REF-parhi2006
- 증거 ID: OB-AP-01-page1-AP-01-0021, OB-AP-03-page1-AP-03-0021

### EF-003 [P1] 과업이 누른 조작 요소에 역할이 없고 키보드로 갈 수 없음

- 체크: `SM-08` · 범주: semantics · 근거: 실측(화면에서 측정, observed)
- 시나리오: `SC-d2-delivery-b` · 대상: `#grp-part-boneless|순살 +2,000원`
- 관찰: 과업에서 누른 '순살 +2,000원'이(가) 버튼·선택 요소로 선언되지 않았고 키보드로 초점을 받을 수 없습니다. 키보드·스크린리더 사용자는 이 단계를 마칠 수 없습니다(WCAG 2.1.1, 4.1.2).
- 측정: role_focusable={'role': None, 'tag': 'div', 'focusable': False} state (기준 in native control, widget role or tabindex >= 0)
- 커버리지: profile-independent (measured on the screen; coverage, not prevalence) — 발생 AP-01, AP-03
- 영향 세그먼트(구성 프로필 기준, 비율 아님): SEG-commuter
- 권장 수정(accessibility): <button>이나 <input type=radio|checkbox>를 쓰거나, role·tabindex=0·키보드 동작(Enter/Space)과 상태(aria-pressed, aria-checked)를 주세요.
- 근거 문헌: REF-wcag22-211, REF-wcag22-412
- 증거 ID: OB-AP-01-page1-AP-01-0084, OB-AP-03-page1-AP-03-0084

### EF-004 [P1] 이름 없는 조작 요소(스크린리더·음성 제어로 식별 불가)

- 체크: `SM-01` · 범주: semantics · 근거: 실측(화면에서 측정, observed)
- 시나리오: `SC-d2-delivery-b` · 대상: `#qty-1-inc|`
- 관찰: 조작 요소 '#qty-1-inc'에 접근 가능한 이름이 없습니다. 스크린리더·음성 제어 사용자는 무엇을 하는 버튼인지 알 수 없습니다(시뮬레이션하지 않는 사용자군).
- 측정: accessible_name= text (기준 != non-empty)
- 커버리지: profile-independent (measured on the screen; coverage, not prevalence) — 발생 AP-01, AP-03
- 영향 세그먼트(구성 프로필 기준, 비율 아님): SEG-commuter
- 권장 수정(accessibility): 아이콘 버튼·링크에 보이는 텍스트나 aria-label을 주세요.
- 근거 문헌: REF-wcag22-412, REF-wcag22-244
- 증거 ID: OB-AP-01-page1-AP-01-0046, OB-AP-03-page1-AP-03-0046

### EF-005 [P2] 조작 지점에서 멀리 뜨는 피드백/오류 메시지(변화맹 위험)

- 체크: `GZ-02` · 범주: gaze · 근거: 모델 예측(inferred) · 모델: `gaze-priority-v3`
- 시나리오: `SC-d2-delivery-a` · 대상: `#coupon-msg|‘HANKI5000’은(는) 없는 쿠폰 코드예요. 철자를 확인해 주세요(`
- 관찰: 조작 지점에서 1° 떨어진 곳에 새 메시지 '‘HANKI5000’은(는) 없는 쿠폰 코드예요. 철자' (돌출 변화, 인지 가능성: likely), 한 손 파지 엄지에 가려질 위치. 마지막 입력 위치에서 계산했습니다. 눈의 화면 투영점은 화면 중심으로 가정했습니다.
- 측정: feedback_eccentricity_deg=1.0 deg (기준 band [10.0, 20.0])
- 커버리지: 1/2 simulated profiles (coverage, not prevalence) — 발생 AP-03
- 차이 조건(발생 프로필에만 공통): `handedness=left`, `grip=one_hand_left`
- 영향 세그먼트(구성 프로필 기준, 비율 아님): SEG-commuter
- 권장 수정(interaction): 오류·상태 메시지를 조작한 위치 가까이(인라인) 표시하고, 필요하면 포커스를 이동하거나 라이브 영역으로 알리세요.
- 근거 문헌: REF-rensink1997, REF-ball-ufov
- 증거 ID: OB-AP-03-page2-AP-03-0054, OB-AP-03-page2-AP-03-0059

### EF-006 [P2] 조작 지점에서 멀리 뜨는 피드백/오류 메시지(변화맹 위험)

- 체크: `GZ-02` · 범주: gaze · 근거: 모델 예측(inferred) · 모델: `gaze-priority-v3`
- 시나리오: `SC-d2-delivery-b` · 대상: `#coupon-msg|쿠폰을 적용할 수 없습니다. (CPN-4003)`
- 관찰: 조작 지점에서 1° 떨어진 곳에 새 메시지 '쿠폰을 적용할 수 없습니다. (CPN-4003)' (돌출 변화, 인지 가능성: likely), 한 손 파지 엄지에 가려질 위치. 마지막 입력 위치에서 계산했습니다. 눈의 화면 투영점은 화면 중심으로 가정했습니다.
- 측정: feedback_eccentricity_deg=1.0 deg (기준 band [10.0, 20.0])
- 커버리지: 1/2 simulated profiles (coverage, not prevalence) — 발생 AP-03
- 차이 조건(발생 프로필에만 공통): `handedness=left`, `grip=one_hand_left`
- 영향 세그먼트(구성 프로필 기준, 비율 아님): SEG-commuter
- 권장 수정(interaction): 오류·상태 메시지를 조작한 위치 가까이(인라인) 표시하고, 필요하면 포커스를 이동하거나 라이브 영역으로 알리세요.
- 근거 문헌: REF-rensink1997, REF-ball-ufov
- 증거 ID: OB-AP-03-page1-AP-03-0066, OB-AP-03-page1-AP-03-0071

### EF-007 [P2] 상자에 잘린 텍스트

- 체크: `LY-01` · 범주: layout · 근거: 실측(화면에서 측정, observed)
- 시나리오: `SC-d2-delivery-b` · 대상: `#grp-sauce-garlic-label > span|간장마늘 +1,000원`
- 관찰: '간장마늘 +1,000원' 글자가 바깥 상자(#grp-sauce-garlic-label)에 잘립니다. 글자를 키우거나 번역되면 더 많이 잘립니다.
- 측정: text_clipped=True flag (기준 == False)
- 커버리지: profile-independent (measured on the screen; coverage, not prevalence) — 발생 AP-01, AP-03
- 영향 세그먼트(구성 프로필 기준, 비율 아님): SEG-commuter
- 권장 수정(visual): 고정 높이·너비와 overflow:hidden을 풀어 글자가 늘어나도 다 보이게 하세요.
- 근거 문헌: REF-xctest-textclipped, REF-wcag22-144, REF-wcag22-1412
- 증거 ID: OB-AP-01-page1-AP-01-0014, OB-AP-03-page1-AP-03-0014

### EF-008 [P2] 상자에 잘린 텍스트

- 체크: `LY-01` · 범주: layout · 근거: 실측(화면에서 측정, observed)
- 시나리오: `SC-d2-delivery-b` · 대상: `#grp-sauce-hot-label > span|매운 양념 +500원`
- 관찰: '매운 양념 +500원' 글자가 바깥 상자(#grp-sauce-hot-label)에 잘립니다. 글자를 키우거나 번역되면 더 많이 잘립니다.
- 측정: text_clipped=True flag (기준 == False)
- 커버리지: profile-independent (measured on the screen; coverage, not prevalence) — 발생 AP-01, AP-03
- 영향 세그먼트(구성 프로필 기준, 비율 아님): SEG-commuter
- 권장 수정(visual): 고정 높이·너비와 overflow:hidden을 풀어 글자가 늘어나도 다 보이게 하세요.
- 근거 문헌: REF-xctest-textclipped, REF-wcag22-144, REF-wcag22-1412
- 증거 ID: OB-AP-01-page1-AP-01-0013, OB-AP-03-page1-AP-03-0013

### EF-009 [P2] 한 손 엄지 도달이 어려운 위치의 조작 대상

- 체크: `RH-01` · 범주: reach · 근거: 모델 예측(inferred) · 모델: `thumb-reach-v3-uncalibrated`
- 시나리오: `SC-d2-delivery-b` · 대상: `#cart-btn|장바구니, 비어 있음`
- 관찰: '장바구니, 비어 있음'은(는) one_hand_right 파지·엄지 107mm 기준 파지를 바꿔야 닿는 위치입니다(난이도 1.00).
- 측정: reach_difficulty=1.0 0-1 (기준 < 0.6)
- 커버리지: 2/2 simulated profiles (coverage, not prevalence) — 발생 AP-01, AP-03
- 영향 세그먼트(구성 프로필 기준, 비율 아님): SEG-commuter
- 권장 수정(interaction): AP-01 조건: 도달 모델 예측(thumb-reach-v3-uncalibrated, 비보정): 오른손 한 손(엄지) 파지, 구역 '파지를 바꿔야 닿는', 난이도 1.00, 대표 지점 60,4mm. AP-03 조건: 도달 모델 예측(thumb-reach-v3-uncalibrated, 비보정): 왼손 한 손(엄지) 파지, 구역 '파지를 바꿔야 닿는', 난이도 1.00, 대표 지점 60,4mm. 주요 조작을 파지 손 엄지의 편한 영역(화면 하단 중앙부)으로 옮기거나 하단 고정 바/대체 경로를 제공하세요. 좌우 대칭 배치 또는 손잡이 설정을 검토하세요.
- 근거 문헌: REF-bergstrom2014, REF-hoober2013
- 증거 ID: OB-AP-01-page1-AP-01-0000, OB-AP-01-page1-AP-01-0030, OB-AP-03-page1-AP-03-0000, OB-AP-03-page1-AP-03-0030

### EF-010 [P2] 보이는 레이블이 접근 가능한 이름에 없음(음성 제어 불일치)

- 체크: `SM-02` · 범주: semantics · 근거: 실측(화면에서 측정, observed)
- 시나리오: `SC-d2-delivery-b` · 대상: `#cart-btn|장바구니, 1개 담김`
- 관찰: 보이는 문구 '1'이(가) 접근 가능한 이름 '장바구니, 1개 담김'에 없습니다. 음성 제어로 보이는 문구를 말해도 작동하지 않습니다.
- 측정: label_in_name=False flag (기준 == True)
- 커버리지: profile-independent (measured on the screen; coverage, not prevalence) — 발생 AP-01, AP-03
- 영향 세그먼트(구성 프로필 기준, 비율 아님): SEG-commuter
- 권장 수정(accessibility): aria-label을 지우거나 보이는 문구로 시작하게 바꾸세요.
- 근거 문헌: REF-wcag22-253
- 증거 ID: OB-AP-01-page1-AP-01-0035, OB-AP-03-page1-AP-03-0035

### EF-011 [P2] 이름 없는 조작 요소(스크린리더·음성 제어로 식별 불가)

- 체크: `SM-01` · 범주: semantics · 근거: 실측(화면에서 측정, observed)
- 시나리오: `SC-d2-delivery-b` · 대상: `#qty-1-dec|`
- 관찰: 조작 요소 '#qty-1-dec'에 접근 가능한 이름이 없습니다. 스크린리더·음성 제어 사용자는 무엇을 하는 버튼인지 알 수 없습니다(시뮬레이션하지 않는 사용자군).
- 측정: accessible_name= text (기준 != non-empty)
- 커버리지: profile-independent (measured on the screen; coverage, not prevalence) — 발생 AP-01, AP-03
- 영향 세그먼트(구성 프로필 기준, 비율 아님): SEG-commuter
- 권장 수정(accessibility): 아이콘 버튼·링크에 보이는 텍스트나 aria-label을 주세요.
- 근거 문헌: REF-wcag22-412, REF-wcag22-244
- 증거 ID: OB-AP-01-page1-AP-01-0051, OB-AP-03-page1-AP-03-0051

### EF-026 [P3] 터치 타깃 물리 크기가 플랫폼 권장치 미만

- 체크: `PT-02` · 범주: pointing · 근거: 실측(화면에서 측정, observed)
- 시나리오: `SC-d2-delivery-a` · 대상: `#line-1-del|반반치킨 삭제`
- 관찰: '반반치킨 삭제' 물리 크기 8.8×8.8mm (기준 9.2mm 이상).
- 측정: target_mm=[8.8, 8.8] mm (기준 >= 9.2)
- 커버리지: 2/2 simulated profiles (coverage, not prevalence) — 발생 AP-01, AP-03
- 영향 세그먼트(구성 프로필 기준, 비율 아님): SEG-commuter
- 권장 수정(visual): AP-01, AP-03 조건: 기록된 타깃 상자를 기기 카탈로그 밀도로 환산하면 8.8×8.8mm(짧은 변 8.8mm)이며 한 손 엄지 조작 기준(Parhi 2006) 9.2mm에 미달했습니다. 짧은 변을 9.2mm 이상으로 키우세요(현재 8.8mm, 0.4mm 이상 증가). mm 값은 카탈로그 밀도로 환산한 추정치이며 44pt/48dp와 정확히 일치하는 단위 환산이 아니므로 플랫폼 도구에서는 pt/dp 권장을 그대로 적용하세요. 터치 타깃을 44pt/48dp(약 7–9mm) 이상으로 키우세요.
- 근거 문헌: REF-apple-hig-44pt, REF-material-48dp, REF-parhi2006
- 증거 ID: OB-AP-01-page2-AP-01-0029, OB-AP-03-page2-AP-03-0029

### EF-027 [P3] 터치 타깃 물리 크기가 플랫폼 권장치 미만

- 체크: `PT-02` · 범주: pointing · 근거: 실측(화면에서 측정, observed)
- 시나리오: `SC-d2-delivery-a` · 대상: `#qty-1-inc|반반치킨 수량 늘리기`
- 관찰: '반반치킨 수량 늘리기' 물리 크기 8.8×8.8mm (기준 9.2mm 이상).
- 측정: target_mm=[8.8, 8.8] mm (기준 >= 9.2)
- 커버리지: 2/2 simulated profiles (coverage, not prevalence) — 발생 AP-01, AP-03
- 영향 세그먼트(구성 프로필 기준, 비율 아님): SEG-commuter
- 권장 수정(visual): AP-01, AP-03 조건: 기록된 타깃 상자를 기기 카탈로그 밀도로 환산하면 8.8×8.8mm(짧은 변 8.8mm)이며 한 손 엄지 조작 기준(Parhi 2006) 9.2mm에 미달했습니다. 짧은 변을 9.2mm 이상으로 키우세요(현재 8.8mm, 0.4mm 이상 증가). mm 값은 카탈로그 밀도로 환산한 추정치이며 44pt/48dp와 정확히 일치하는 단위 환산이 아니므로 플랫폼 도구에서는 pt/dp 권장을 그대로 적용하세요. 터치 타깃을 44pt/48dp(약 7–9mm) 이상으로 키우세요.
- 근거 문헌: REF-apple-hig-44pt, REF-material-48dp, REF-parhi2006
- 증거 ID: OB-AP-01-page2-AP-01-0030, OB-AP-03-page2-AP-03-0030

### EF-028 [P3] 예측 오터치 확률이 높은 조작 대상

- 체크: `PT-04` · 범주: pointing · 근거: 모델 예측(inferred) · 모델: `bi-zhai-2016-dual-gaussian`
- 시나리오: `SC-d2-delivery-a` · 대상: `#qty-1-inc|반반치킨 수량 늘리기`
- 관찰: '반반치킨 수량 늘리기' 예측 오터치 확률 19.8% (기준 인구 0.6%, σ배수 1.82, 8.8×8.8mm).
- 측정: miss_probability=0.1976 probability (기준 < 0.03)
- 커버리지: 2/2 simulated profiles (coverage, not prevalence) — 발생 AP-01, AP-03
- 영향 세그먼트(구성 프로필 기준, 비율 아님): SEG-commuter
- 권장 수정(visual): AP-01, AP-03 조건: 이 타깃(8.8×8.8mm)의 예측 놓침 확률(이중 가우시안, Bi & Zhai 2016): 기준 모델(k=1) 0.6% → 이 조건 19.8%(σ배수 1.82, 선언된 가정). 모델 동등 크기 비교: 기준 모델의 9.2mm 정사각형은 예측 놓침 0.46%입니다. 이 조건에서 같은 적중 확률이 되는 크기를 계산했습니다. 40mm 탐색 범위 안에서는 해당 크기를 찾지 못했습니다. 범위 밖의 값은 미확인입니다. 타깃 크기와 간격을 키우고, 이동 중·손떨림 사용자를 위한 여유 영역(hit slop)을 두세요.
- 근거 문헌: REF-bi-zhai2013, REF-henze2011, REF-parhi2006
- 증거 ID: OB-AP-01-page2-AP-01-0031, OB-AP-03-page2-AP-03-0031

### EF-029 [P3] 터치 타깃 물리 크기가 플랫폼 권장치 미만

- 체크: `PT-02` · 범주: pointing · 근거: 실측(화면에서 측정, observed)
- 시나리오: `SC-d2-delivery-b` · 대상: `#cart-btn|장바구니, 비어 있음`
- 관찰: '장바구니, 비어 있음' 물리 크기 8.8×8.8mm (기준 9.2mm 이상).
- 측정: target_mm=[8.8, 8.8] mm (기준 >= 9.2)
- 커버리지: 2/2 simulated profiles (coverage, not prevalence) — 발생 AP-01, AP-03
- 영향 세그먼트(구성 프로필 기준, 비율 아님): SEG-commuter
- 권장 수정(visual): AP-01, AP-03 조건: 기록된 타깃 상자를 기기 카탈로그 밀도로 환산하면 8.8×8.8mm(짧은 변 8.8mm)이며 한 손 엄지 조작 기준(Parhi 2006) 9.2mm에 미달했습니다. 짧은 변을 9.2mm 이상으로 키우세요(현재 8.8mm, 0.4mm 이상 증가). mm 값은 카탈로그 밀도로 환산한 추정치이며 44pt/48dp와 정확히 일치하는 단위 환산이 아니므로 플랫폼 도구에서는 pt/dp 권장을 그대로 적용하세요. 터치 타깃을 44pt/48dp(약 7–9mm) 이상으로 키우세요.
- 근거 문헌: REF-apple-hig-44pt, REF-material-48dp, REF-parhi2006
- 증거 ID: OB-AP-01-page1-AP-01-0002, OB-AP-01-page1-AP-01-0031, OB-AP-03-page1-AP-03-0002, OB-AP-03-page1-AP-03-0031

### EF-030 [P3] 예측 오터치 확률이 높은 조작 대상

- 체크: `PT-04` · 범주: pointing · 근거: 모델 예측(inferred) · 모델: `bi-zhai-2016-dual-gaussian`
- 시나리오: `SC-d2-delivery-b` · 대상: `#cart-btn|장바구니, 비어 있음`
- 관찰: '장바구니, 비어 있음' 예측 오터치 확률 19.8% (기준 인구 0.6%, σ배수 1.82, 8.8×8.8mm).
- 측정: miss_probability=0.1976 probability (기준 < 0.03)
- 커버리지: 2/2 simulated profiles (coverage, not prevalence) — 발생 AP-01, AP-03
- 영향 세그먼트(구성 프로필 기준, 비율 아님): SEG-commuter
- 권장 수정(visual): AP-01, AP-03 조건: 이 타깃(8.8×8.8mm)의 예측 놓침 확률(이중 가우시안, Bi & Zhai 2016): 기준 모델(k=1) 0.6% → 이 조건 19.8%(σ배수 1.82, 선언된 가정). 모델 동등 크기 비교: 기준 모델의 9.2mm 정사각형은 예측 놓침 0.46%입니다. 이 조건에서 같은 적중 확률이 되는 크기를 계산했습니다. 40mm 탐색 범위 안에서는 해당 크기를 찾지 못했습니다. 범위 밖의 값은 미확인입니다. 타깃 크기와 간격을 키우고, 이동 중·손떨림 사용자를 위한 여유 영역(hit slop)을 두세요.
- 근거 문헌: REF-bi-zhai2013, REF-henze2011, REF-parhi2006
- 증거 ID: OB-AP-01-page1-AP-01-0003, OB-AP-01-page1-AP-01-0032, OB-AP-03-page1-AP-03-0003, OB-AP-03-page1-AP-03-0032

### EF-031 [P3] 터치 타깃 물리 크기가 플랫폼 권장치 미만

- 체크: `PT-02` · 범주: pointing · 근거: 실측(화면에서 측정, observed)
- 시나리오: `SC-d2-delivery-b` · 대상: `#line-1-del|반반치킨 삭제`
- 관찰: '반반치킨 삭제' 물리 크기 8.8×8.8mm (기준 9.2mm 이상).
- 측정: target_mm=[8.8, 8.8] mm (기준 >= 9.2)
- 커버리지: 2/2 simulated profiles (coverage, not prevalence) — 발생 AP-01, AP-03
- 영향 세그먼트(구성 프로필 기준, 비율 아님): SEG-commuter
- 권장 수정(visual): AP-01, AP-03 조건: 기록된 타깃 상자를 기기 카탈로그 밀도로 환산하면 8.8×8.8mm(짧은 변 8.8mm)이며 한 손 엄지 조작 기준(Parhi 2006) 9.2mm에 미달했습니다. 짧은 변을 9.2mm 이상으로 키우세요(현재 8.8mm, 0.4mm 이상 증가). mm 값은 카탈로그 밀도로 환산한 추정치이며 44pt/48dp와 정확히 일치하는 단위 환산이 아니므로 플랫폼 도구에서는 pt/dp 권장을 그대로 적용하세요. 터치 타깃을 44pt/48dp(약 7–9mm) 이상으로 키우세요.
- 근거 문헌: REF-apple-hig-44pt, REF-material-48dp, REF-parhi2006
- 증거 ID: OB-AP-01-page1-AP-01-0039, OB-AP-03-page1-AP-03-0039

### EF-032 [P3] 터치 타깃 물리 크기가 플랫폼 권장치 미만

- 체크: `PT-02` · 범주: pointing · 근거: 실측(화면에서 측정, observed)
- 시나리오: `SC-d2-delivery-b` · 대상: `#qty-1-inc|`
- 관찰: '#qty-1-inc' 물리 크기 8.8×8.8mm (기준 9.2mm 이상).
- 측정: target_mm=[8.8, 8.8] mm (기준 >= 9.2)
- 커버리지: 2/2 simulated profiles (coverage, not prevalence) — 발생 AP-01, AP-03
- 영향 세그먼트(구성 프로필 기준, 비율 아님): SEG-commuter
- 권장 수정(visual): AP-01, AP-03 조건: 기록된 타깃 상자를 기기 카탈로그 밀도로 환산하면 8.8×8.8mm(짧은 변 8.8mm)이며 한 손 엄지 조작 기준(Parhi 2006) 9.2mm에 미달했습니다. 짧은 변을 9.2mm 이상으로 키우세요(현재 8.8mm, 0.4mm 이상 증가). mm 값은 카탈로그 밀도로 환산한 추정치이며 44pt/48dp와 정확히 일치하는 단위 환산이 아니므로 플랫폼 도구에서는 pt/dp 권장을 그대로 적용하세요. 터치 타깃을 44pt/48dp(약 7–9mm) 이상으로 키우세요.
- 근거 문헌: REF-apple-hig-44pt, REF-material-48dp, REF-parhi2006
- 증거 ID: OB-AP-01-page1-AP-01-0040, OB-AP-03-page1-AP-03-0040

### EF-033 [P3] 예측 오터치 확률이 높은 조작 대상

- 체크: `PT-04` · 범주: pointing · 근거: 모델 예측(inferred) · 모델: `bi-zhai-2016-dual-gaussian`
- 시나리오: `SC-d2-delivery-b` · 대상: `#qty-1-inc|`
- 관찰: '' 예측 오터치 확률 19.8% (기준 인구 0.6%, σ배수 1.82, 8.8×8.8mm).
- 측정: miss_probability=0.1976 probability (기준 < 0.03)
- 커버리지: 2/2 simulated profiles (coverage, not prevalence) — 발생 AP-01, AP-03
- 영향 세그먼트(구성 프로필 기준, 비율 아님): SEG-commuter
- 권장 수정(visual): AP-01, AP-03 조건: 이 타깃(8.8×8.8mm)의 예측 놓침 확률(이중 가우시안, Bi & Zhai 2016): 기준 모델(k=1) 0.6% → 이 조건 19.8%(σ배수 1.82, 선언된 가정). 모델 동등 크기 비교: 기준 모델의 9.2mm 정사각형은 예측 놓침 0.46%입니다. 이 조건에서 같은 적중 확률이 되는 크기를 계산했습니다. 40mm 탐색 범위 안에서는 해당 크기를 찾지 못했습니다. 범위 밖의 값은 미확인입니다. 타깃 크기와 간격을 키우고, 이동 중·손떨림 사용자를 위한 여유 영역(hit slop)을 두세요.
- 근거 문헌: REF-bi-zhai2013, REF-henze2011, REF-parhi2006
- 증거 ID: OB-AP-01-page1-AP-01-0042, OB-AP-03-page1-AP-03-0042

### EF-034 [P3] 한 손 엄지 도달이 어려운 위치의 조작 대상

- 체크: `RH-01` · 범주: reach · 근거: 모델 예측(inferred) · 모델: `thumb-reach-v3-uncalibrated`
- 시나리오: `SC-d2-delivery-a` · 대상: `#qty-1-inc|반반치킨 수량 늘리기`
- 관찰: '반반치킨 수량 늘리기'은(는) one_hand_left 파지·엄지 107mm 기준 파지를 바꿔야 닿는 위치입니다(난이도 1.00).
- 측정: reach_difficulty=1.0 0-1 (기준 < 0.6)
- 커버리지: 1/2 simulated profiles (coverage, not prevalence) — 발생 AP-03
- 차이 조건(발생 프로필에만 공통): `handedness=left`, `grip=one_hand_left`
- 영향 세그먼트(구성 프로필 기준, 비율 아님): SEG-commuter
- 권장 수정(interaction): AP-03 조건: 도달 모델 예측(thumb-reach-v3-uncalibrated, 비보정): 왼손 한 손(엄지) 파지, 구역 '파지를 바꿔야 닿는', 난이도 1.00, 대표 지점 59,40mm. 주요 조작을 파지 손 엄지의 편한 영역(화면 하단 중앙부)으로 옮기거나 하단 고정 바/대체 경로를 제공하세요. 좌우 대칭 배치 또는 손잡이 설정을 검토하세요.
- 근거 문헌: REF-bergstrom2014, REF-hoober2013
- 증거 ID: OB-AP-03-page2-AP-03-0027

### EF-035 [P3] 한 손 엄지 도달이 어려운 위치의 조작 대상

- 체크: `RH-01` · 범주: reach · 근거: 모델 예측(inferred) · 모델: `thumb-reach-v3-uncalibrated`
- 시나리오: `SC-d2-delivery-b` · 대상: `#qty-1-inc|`
- 관찰: '#qty-1-inc'은(는) one_hand_left 파지·엄지 107mm 기준 파지를 바꿔야 닿는 위치입니다(난이도 1.00).
- 측정: reach_difficulty=1.0 0-1 (기준 < 0.6)
- 커버리지: 1/2 simulated profiles (coverage, not prevalence) — 발생 AP-03
- 차이 조건(발생 프로필에만 공통): `handedness=left`, `grip=one_hand_left`
- 영향 세그먼트(구성 프로필 기준, 비율 아님): SEG-commuter
- 권장 수정(interaction): AP-03 조건: 도달 모델 예측(thumb-reach-v3-uncalibrated, 비보정): 왼손 한 손(엄지) 파지, 구역 '파지를 바꿔야 닿는', 난이도 1.00, 대표 지점 59,40mm. 주요 조작을 파지 손 엄지의 편한 영역(화면 하단 중앙부)으로 옮기거나 하단 고정 바/대체 경로를 제공하세요. 좌우 대칭 배치 또는 손잡이 설정을 검토하세요.
- 근거 문헌: REF-bergstrom2014, REF-hoober2013
- 증거 ID: OB-AP-03-page1-AP-03-0038

## 5-1. 검토용 가설 (결함으로 세지 않음)

검증에서 고유 탐지가 없고 판정 타당도가 낮았던 모델 체크입니다(GZ-01, GZ-04, PC-05). 디자인 검토의 단서로만 쓰세요.

- GZ-01 주요 동작이 초기 시선 경로에 들어오지 않음 · SC-d2-delivery-a · 조건 all tested profiles · 요소 5개 (#add-to-cart, #coupon-apply, #menu-banban, #order-btn)
- GZ-04 주요 동작보다 눈에 띄는 경쟁 요소가 많음 · SC-d2-delivery-a · 조건 all tested profiles · 요소 1개 (#menu-banban)
- GZ-01 주요 동작이 초기 시선 경로에 들어오지 않음 · SC-d2-delivery-b · 조건 all tested profiles · 요소 6개 (#add-to-cart, #cart-btn, #coupon-apply, #menu-banban)
- GZ-04 주요 동작보다 눈에 띄는 경쟁 요소가 많음 · SC-d2-delivery-b · 조건 all tested profiles · 요소 2개 (#cart-btn, #menu-banban)

## 6. 자동화하지 않은 판단 (사람/비전 LLM 확인 필요)

- WCAG 2.5.8 예외(인라인·동등 대안·필수) 해당 여부, 동작의 비가역성, 시각적 위계가 실제로 주요 버튼처럼 읽히는지.
- 실제 파지 습관·파지 전환, 손에 가려진 메시지를 실제로 놓쳤는지, 피로·통증.
- 게임 의도(QTE·연타가 설계 의도인지), 좌우 반전 HUD의 품질, 광고처럼 보이는지(배너 블라인드니스).

## 7. 다음 검증

- P0/P1 및 모델 기반 P2는 해당 조건의 실제 사용자(예: 왼손 한 손 파지, 노안, 색각이상) 과제 테스트로 확인하세요.
- 커뮤니티 리서치(aside-community-ux-research)로 같은 문제의 실제 사용자 언급을 교차 확인하세요.
- 수정 후 같은 시나리오·기기·프로필로 재실행해 회귀를 확인하세요.
