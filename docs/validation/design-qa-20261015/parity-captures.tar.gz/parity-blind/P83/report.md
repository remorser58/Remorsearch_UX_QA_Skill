# Delivery UX QA

Both variants were exercised through the requested order flow at 384x832, 320x568 and 1440x900. A retained all requested final values. B completed at the correct 48,000원 but lost the allergy note after the missing-address error; its final order showed 가게 요청: 없음.

The highest-priority corrections are B's allergy-note preservation and required body-part keyboard access. Tab skips the bone/boneless choices, which are exposed as plain text in the accessible snapshot. B also fails to explain an add attempt without sauce, clips sauce surcharges on narrow screens, leaves cart quantity buttons unnamed, and gives only an internal coupon error code without spelling guidance. Six deduplicated findings, reproduction steps and evidence references are in findings.json.

Both variants correctly calculated one item at 25,000원, two at 50,000원, and 48,000원 after 3,000원 delivery and a 5,000원 coupon. The corrected coupon, delivery instruction, detail address and 동네페이 selection survived recovery. Final summaries were inspected rather than relying on success banners.

Screenshots were visually reviewed for alignment, wrapping, clipping, fixed headers and action areas. B's sauce prices were visibly cut off at both narrow widths and fit at desktop width. Other reviewed wrapping and scrolling did not establish an additional reading or action failure. Keyboard sauce selection with ArrowRight and its visible focus ring worked in both variants.

Figma fidelity is unknown. This run used an owned headless Chromium context and synthetic data; real devices, screen-reader speech, virtual keyboards and real fulfillment were not tested. Keyboard coverage was bounded, not a full keyboard-only order.

One diagnostic accidentally included embedded script text when keyboard focus reached the document body. It was excluded from the findings, and a bounded focus probe replaced it. This method deviation prevents a claim of perfect source-blind compliance. interaction-evidence.md records the rendered observations and that limitation.
