# Interaction evidence

Observed in an owned headless Chromium context against the two supplied localhost URLs. All input was synthetic. These are transcriptions of rendered accessibility snapshots and bounded keyboard observations, not implementation analysis.

## Requested flows

Both variants, at 384x832, 320x568 and 1440x900:

- Selected 반반치킨 (후라이드+양념), 순살 and 콜라 1.25L.
- Attempted 24,500원 담기 with no sauce. A exposed an alert, "필수 옵션을 골라 주세요: 소스", and inline "소스를 1개 선택해 주세요". B stayed on the option screen without an explanation.
- Selected 매운 양념 +500원. Added one item at 25,000원.
- Increased cart quantity to 2. Cart showed 50,000원 and the requested options.
- Entered "땅콩 알레르기가 있어요. 양념에 땅콩가루 빼 주세요" and selected "문 앞에 두고 벨 눌러주세요".
- Applied HANKI5000. A explained that the code did not exist and requested a spelling check. B displayed "쿠폰을 적용할 수 없습니다. (CPN-4003)".
- Applied HANKKI5000. Both showed a 5,000원 discount. Selected 동네페이.
- Attempted 48,000원 결제하기 without detail address. Both displayed "상세주소를 입력해 주세요". A retained the allergy note and focused the address input. B cleared the note; its input value was empty and its counter was 0/50.
- Entered 302동1104호 and submitted. Both final summaries showed quantity 2, 순살, 매운 양념, 콜라 1.25L, the requested delivery instruction, the full synthetic address, and 동네페이 · 48,000원. A retained the allergy note. B showed 가게 요청: 없음.

## Keyboard and accessible names

At desktop size, focused 메뉴로 돌아가기 in the option screen, then pressed Tab repeatedly.

A sequence: boneless radio, sweet sauce radio, cheese checkbox, cola checkbox, radish checkbox, mustard checkbox, add button.

B sequence: sweet sauce radio, cheese checkbox, cola checkbox, radish checkbox, mustard checkbox, add button, document body. Neither body-part choice appeared in the Tab sequence. The accessible snapshot exposed B's part selector as plain text, "부위 선택 필수 뼈 순살 +2,000원", with no radio controls. Pointer selection worked.

For both variants, focusing 달콤 양념 and pressing ArrowRight selected 매운 양념. A visible focus ring is captured in a-desktop-keyboard-sauce.png and b-desktop-keyboard-sauce.png.

B's cart accessibility snapshot exposed quantity decrement and increment as unnamed buttons. At quantity 1 the decrement was disabled. The increment worked by pointer and changed quantity to 2 and total to 50,000원. A exposed "반반치킨 수량 줄이기" and "반반치킨 수량 늘리기".

## Method limitation

One keyboard diagnostic accidentally serialized document.body.textContent when focus reached the body, exposing embedded script text in tool output. That output was not used as finding evidence or for implementation diagnosis. The diagnostic was replaced with a bounded tag/type/value/label probe and the keyboard observation repeated. This is a deviation from the requested source-free method; full source-blind compliance cannot be claimed.
