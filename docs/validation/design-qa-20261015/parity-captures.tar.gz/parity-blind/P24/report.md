# Delivery variant UX QA

## Decision

Hold variant B for the tested task. Missing-address validation removes the allergy note, and keyboard users cannot select the required chicken part. Variant A completed the requested pointer and keyboard flows with intact final values. Broader readiness remains inconclusive: desktop coverage used resized key states, the immutable build is unknown, and Figma was unavailable.

1. Preserve the allergy note through address errors and verify it in the final order (F01).
2. Make chicken-part selection keyboard-operable and name both quantity controls (F02, F05).
3. Restore readable narrow-width prices and specific missing-sauce feedback (F03, F04).

Untested: independent desktop-only full flow, real devices, screen readers, Safari, text resizing/spacing, network failures and Figma fidelity.

## Findings

| ID | Severity | Observed result |
| --- | --- | --- |
| F01 | P1 | B clears the allergy note on missing-address submission. Final order says `가게 요청 없음`, despite successful ordering. |
| F02 | P1 | B's required part choices are skipped by Tab and lack control semantics. Keyboard-only ordering stops here. |
| F03 | P2 | B clips sauce surcharges at 384 and 320 px. At 320 px the payment summary requires horizontal scrolling, trading visible amounts for clipped labels. |
| F04 | P2 | B rejects adding without sauce without explaining the missing selection. Manually selecting sauce recovers. |
| F05 | P2 | B's working quantity buttons have no accessible names. Their visual minus/plus symbols remain visible. |

The allergy note was intact after coupon correction and empty immediately after address validation. This isolates the observed trigger; a particular implementation reset mechanism remains inferred. Compare [before validation](b-note-before-validation.png), [after validation](b-note-after-validation.png), and [final order](b-mobile-final.png). The data loss reproduced in the second flow. Potential allergy consequences are inferred; this fixture involved no real food or payment.

The keyboard trace records a complete option tab cycle without either part choice. [The focused sauce state](b-keyboard-options.png) and [blocked add state](b-keyboard-blocked.png) corroborate the task failure. DOM inspection found the part choice rendered as a DIV without role or tabindex. Pointer selection worked. The underlying code and organizational constraints were not inspected.

The visual finding is based on painted frames, not rectangle intersections alone. Compare [B's short options](b-short-selected.png), [B's short summary](b-short-payment-summary.png), [its horizontally scrolled state](b-short-payment-horizontal-end.png), and [A's readable summary](a-short-payment-summary.png). The B summary measured 360 px within a 320 px viewport. Its amounts can be reached by horizontal scrolling; they are not permanently inaccessible.

Both P1 findings received a capture/text self-review, recorded in `observations.json`; this was not an independent review. Detailed steps, expected results, limitations and evidence references are in `findings.json`.

## Task completion and coverage

Both pointer flows reached a final order showing the requested meal, boneless option, hot sauce, cola, quantity 2, delivery request, synthetic detail address and 동네페이 payment. Each item was 25,000원, cart total 50,000원, coupon discount 5,000원 and delivery fee 3,000원, giving 48,000원. Only A retained the supplied allergy note.

| Variant | 384 x 832 | 320 x 568 | 1440 x 900 |
| --- | --- | --- | --- |
| A | Full pointer flow and full keyboard flow passed the supplied task, including all three recoveries. | Options, errors, cart, coupon, payment summary and final values inspected during replay. | Options, cart, address error, payment summary and final state visually inspected; no independent desktop-only flow. |
| B | Pointer completion failed input integrity; keyboard flow blocked. Sauce price clipping observed. | Note loss reproduced; sauce prices and payment summary have reading failures. | Key states readable in inspected frames; final note still missing in the resized replay. |

Reviewed alignment, wrapping, clipping, selected states, error states and fixed header/footer interactions. Normal content scrolling beneath fixed chrome was not flagged where it remained reachable. Cart and final-order content wrapped readably in the inspected frames. Every scroll position and every possible overlay was not audited.

## Method and limits

Testing used the existing Playwright installation with owned headless Chromium contexts, DPR 1, and the two supplied localhost URLs. Only rendered pages, accessible DOM and captured images were inspected. No delegation, external websites, installation, account access or product edits occurred. Synthetic fixture interactions and local evidence/report writes were authorized.

`capture-receipts.json` contains capture-time timestamps, SHA-256 hashes, URLs, viewport dimensions and rendered text. `observations.json` contains keyboard navigation and preservation checks. Build identity is unknown; screenshot hashes establish artifact integrity, not application version identity.

Figma fidelity is unknown. KWCAG 2.2 and WCAG 2.2 conformance are each unconfirmed: official standards were not accessed and assistive technology was not exercised. Browser viewport emulation does not establish physical-device or software-keyboard behavior. The generic coupon error's effect on user confusion is an unsupported hypothesis, separated in `findings.json`; correction itself succeeded.

No accepted fixes or post-fix replay were performed.
