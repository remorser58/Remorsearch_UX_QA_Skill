# Remorsearch design QA — civil & LMS (leaf, read-only)

Date: 2026-10-15 · Tester: leaf QA agent · Server: http://127.0.0.1:8877 (existing local Python server)
Pages: /dev-2/site/civil/civil-a.html, civil-b.html, /dev-2/site/lms/lms-a.html, lms-b.html
Driver: existing Playwright (chromium-1194), Node /private/tmp/remorsearch-node22. No fixture/source edits; synthetic fake identity data only (scenario task_goal_ko values). No Figma was provided — visual fidelity is UNVERIFIED; findings below are reading/action/rendering failures only.

## Counts
- Pages screened: 4/4 (top/bottom/key states at 384x832, 320x568, 1440x900; full-page at 384)
- Full task completed end-to-end: 2/4 — civil-b (receipt), lms-b (100점 통과)
- Blocked mid-flow: 1/4 — civil-a (step 1), classification pending real-keystroke replay
- Inconclusive: 1/4 — lms-a quiz answer registration
- Findings: 2 concrete (F1, F2) + 2 inconclusive items (F3, F4). No high-confidence page-breaking defect proven.
- Evidence: screens/ (top/bottom/focus for 4 pages x 3 viewports + flow-*/probe-*/final-* step captures), metrics/report.json (per-viewport metrics), metrics/flow_log.json, metrics/final_log.json.

## Findings

### F1 — civil-a: entered 주민등록번호 values not retained after validation error (MEDIUM, replay needed)
- URL/state: civil/civil-a.html, step 1/5 신청인 정보, after clicking 다음 with blank 성명. Viewport 384x832.
- Steps: enter RRN 580312-2084517 + phone (scripted input) → 다음 → error shown → enter 성명 김순자 → 다음.
- Expected: per scenario, fix only the missing field and continue; already-entered data preserved.
- Observed: after the first 다음 the RRN fields rendered empty; the second 다음 raised "주민등록번호 앞 6자리를 입력해 주세요." / "주민등록번호 뒤 7자리를 입력해 주세요." and step 2 was not reached. Same script on civil-b retained "580312"/"2084517" and reached step 2 (phone even auto-formatted 010-4827-3391).
- Impact if reproducible with real input: identity data must be re-entered; flow blocked until re-entry.
- Caveat: scripted JS input/change without real blur; civil-a may commit on blur only. Real-keystroke replay needed before calling this a product defect.
- Evidence: final-civil-a-41-after-name-fix.png, probe-civil-a-20-step1-error.png, metrics/final_log.json (civil-a after-next-blank-name fields / after-name-fix fields).

### F2 — civil-a: error message rendered under sticky header+stepper, text clipped (MEDIUM)
- Same URL/state as F1. Viewport 384x832.
- Expected: validation error fully readable, adjacent to the invalid field.
- Observed: "성명을 입력해 주세요." rendered at top≈54px, overlapping sticky header (0–56) and sticky stepper (56–96); red text clipped mid-line behind the stepper bar in screenshots. In civil-b the same error rendered at top≈190 (fully visible). Also the invalid field was scrolled to top≈0 (under the header) in civil-a.
- Impact: user may not read why submission failed. Sticky headers covering scrolled content is normal; the flagged case is an error message inserted into the overlapped zone.
- Evidence: final-civil-a-41-after-name-fix.png (red text clipped under "단계 1/5 · 신청인 정보"), probe-civil-a-21-step2.png, metrics/final_log.json (civil-a after-next-blank-name errors top:54; civil-b top:190).

### F3 — lms-a: quiz answers did not register in scripted run (INCONCLUSIVE, replay needed)
- URL/state: lms/lms-a.html, 최종평가 응시 flow. Viewport 384x832.
- Observed: option clicks (③ 여권번호 etc.) did not persist — selected list stayed empty; 임시 저장 still showed "임시 저장됨"; 답안 제출 produced no captured confirm dialog; after 계속 풀기 nothing was preserved; result page 0점 평가 미통과 with all 문항 미응답. Identical script on lms-b registered answers, showed the submit dialog ("5문항 중 5문항에 답했습니다"), preserved answers after 계속 풀기, and reached 100점 평가 통과.
- Status: my dialog capture may have missed a custom overlay and/or blocked option clicks; cannot attribute to the product without replay. The blank-question guard itself worked in lms-a ("3번 문항에 답하지 않았습니다" + 3번 문항으로 이동 button, 153x44).
- Evidence: final-lms-a-55-quiz-partial.png, final-lms-a-56-blank-warning.png, final-lms-a-60-result.png, metrics/final_log.json (lms-a selected partial, submit dialog [], result).

### F4 — LMS both: end-of-video completion not reflected (INCONCLUSIVE, replay needed)
- Observed: after seek to 744→758/760 and playback, 학습 현황 stayed 진도율 60% (3/5차시) and lesson 4 stayed "학습 중" in both variants. Playback never reached 760/760 (final values 758, 759), so the end condition may simply not have fired.
- Impact if reproducible at true 100%: learner cannot advance progress after finishing a lesson.
- Evidence: final-lms-a-52/flow-lms-a-07-progress-after-watch.png, flow-lms-b-07, metrics/final_log.json (progress after watch; seek values).

## Verified behaviors (direct evidence)
- civil-b end-to-end at 384x832: address search "새솔로128" → guidance "‘새솔로128’ 검색 결과가 없어요. 도로명과 건물번호 사이를 띄어 입력해 보세요."; "새솔로 128" → picked 새솔마을2단지 → zip 04092 + base address auto-filled; options 최근 5년 포함 + 2통 → fee 3,330원 shown; auth 모아톡 인증 요청 → 인증 완료; agree → submit dialog with fee notice (3,330원, 결제 링크 안내) → receipt "신청이 접수되었어요", 접수번호 2026-0928-104713, 결제 대기. Screens: final-civil-b-42..47.
- lms-b end-to-end: course entry; video 자막 on (aria-pressed true), 배속 1.5x, seek; blank-q3 submit → inline warning + 이동 button; 임시 저장 → "임시 저장됨 · 00:48"; 답안 제출 → dialog, 계속 풀기 preserved all 4 answers + 단답 72; 제출하기 → 100점 평가 통과, 5/5 정답 (제출 2026.10.15 00:48, 응시 1회/2회). Screens: final-lms-b-50..60.
- No page JS errors (pageerror) on any of the 4 pages; no page-level horizontal overflow at 384/320/1440 (docScrollW == clientW on all 12 page/viewport combos).
- Civil fee table at 384/320: columns extend beyond viewport with explicit hint "표를 옆으로 밀면 더 볼 수 있어요" → treated as intentional horizontal scroll, NOT a defect. (In-container reachability by swipe not scroll-tested — gap.)
- Skip link present ("본문 바로가기"); sticky header/stepper, focus traversal screenshots captured.

## Tested / Unverified
| Check | civil-a | civil-b | lms-a | lms-b |
|---|---|---|---|---|
| Load + render 3 viewports | tested | tested | tested | tested |
| Full task completion | blocked (F1) | verified | inconclusive (F3) | verified |
| Validation error recovery | observed (F1/F2) | verified | blank-q guard verified | verified |
| Input preservation on error | not retained (scripted) | retained | answers lost (F3) | answers retained |
| Address search no-result/success | not reached | verified | n/a | n/a |
| Auth 인증 완료 flow | not reached | verified | n/a | n/a |
| Submit confirm + receipt | not reached | verified | no dialog captured | verified |
| Video CC/배속/seek | n/a | n/a | tested | tested |
| Progress reflected after watch | n/a | n/a | inconclusive (F4) | inconclusive (F4) |
| Keyboard focus outlines | captured, not analyzed | captured, not analyzed | captured, not analyzed | captured, not analyzed |
| Figma fidelity | unverified | unverified | unverified | unverified |

## Gaps
- civil-a: completion not verified; F1/F2 need real-keystroke replay (type + real click, real blur) to separate product behavior from scripted-input effects.
- lms-a: replay quiz with explicit dialog/overlay capture; verify whether option clicks register for a real user.
- F4: replay with playback guaranteed to hit 760/760 before reading 진도율.
- Not done: console (beyond pageerror) capture, table horizontal swipe test, focus-outline quality review, 320x568 full-flow runs (320 used for key states only).

