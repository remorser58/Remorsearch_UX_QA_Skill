# Delivery variants UX QA

## Decision

Hold variant B for the tested task: keyboard users cannot choose the required chicken part, and missing-address validation silently removes the allergy request. Variant A completed the specified mobile pointer and keyboard flows with all requested final values intact. Broader readiness remains inconclusive because the run sampled key states at short and desktop sizes and the build versions are unknown.

1. Preserve the allergy request through address validation and final confirmation (F01).
2. Make the required part selector keyboard-operable and name the quantity buttons (F02, F06).
3. Restore readable mobile prices and explicit missing-sauce feedback (F03-F05).

Not tested: Figma fidelity, physical devices, screen readers, Safari/WebKit, text enlargement/spacing, Korean IME, and backend fulfilment.

## Findings

| ID | Impact | Observed result | Evidence |
| --- | --- | --- | --- |
| F01 | P1 | B clears the allergy note on missing-address submit. The final order says `가게 요청 없음`. | `b-mobile-coupon-error.png`, `b-mobile-address-error.png`, `b-mobile-final.png` |
| F02 | P1 | B's required part choices are skipped by Tab. Keyboard selection of sauce and cola cannot complete add without a part. | `b-keyboard-blocked-add.png`, `keyboard-trace.json`, `dom-observations.json` |
| F03 | P2 | B's sauce cards crop surcharge text at 384 and 320 pixels, including the selected state. | `b-mobile-sauce-error.png`, `b-short-sauce-selected.png` |
| F04 | P2 | B's payment summary overflows the 320-pixel viewport. Panning reveals amounts while cutting off left labels. | `b-short-payment-bottom.png`, `b-short-payment-right-edge.png` |
| F05 | P2 | B blocks an add with omitted sauce without identifying the missing choice through new error feedback. | `b-mobile-sauce-error.png`, `b-short-sauce-error.png` |
| F06 | P2 | B's minus/plus quantity buttons have no accessible names, although pointer activation changes the quantity correctly. | `b-mobile-cart-one.png`, `dom-observations.json` |

Each listed screenshot has an adjacent JSON receipt with its capture time, SHA-256, URL, viewport, rendered text and visible input values. Full reproduction steps, expected outcomes, fixes and limits are in `findings.json`.

F01 was reproduced at both mobile widths. The note survives the typo and corrected coupon attempts, then disappears immediately after the missing-address submission. Correcting only the address leaves the final order without the note. Retyping the note after the error restores it, verified in `b-desktop-recovered-final.png`. The observed mechanism is unrelated input loss during validation; its implementation cause is unknown. Possible real-world safety consequences are inferred, not measured in this fake fixture.

F02 was reproduced in a fresh keyboard attempt at 384 pixels and corroborated by a full focus cycle at 320 pixels. Required part choices are non-focusable DIVs in the accessible DOM. The resulting unset choice blocks add. Pointer selection is a workaround for pointer users, not keyboard users. Deeper implementation and organizational causes are unknown.

The two P1 findings received a capture/text self-review recorded in `second-pass.json`. No severity disagreement remained. This was not an independent review.

## Task integrity

Both variants calculated one configured item as 25,000원, quantity two as 50,000원, and the corrected coupon as a 5,000원 reduction. Including 3,000원 delivery, both displayed 48,000원 with 동네페이 and `302동1104호`.

A retained `땅콩 알레르기가 있어요. 양념에 땅콩가루 빼 주세요` and `문 앞에 두고 벨 눌러주세요` through errors and final confirmation. Its keyboard-only run also preserved those values (`a-keyboard-final.png`, `a-keyboard-flow.json`).

B retained the delivery request, choices, quantity, address and payment amount. Its first confirmation failed the requested task because the allergy note was absent. A success banner was not counted as intact completion.

## Rendered coverage

| Viewport | A | B |
| --- | --- | --- |
| 384 x 832 | Full specified flow, error states, cart, final values, payment selection, deletion overlay; complete keyboard flow. | Full pointer flow through failed integrity confirmation; keyboard blocked; same principal visual states inspected. |
| 320 x 568 | Menu, options/error/selection, cart, coupon/address recovery, payment summary and deletion overlay; resized final inspected at top and bottom. | Same sampled states; sauce clipping and payment overflow observed; note loss reproduced. |
| 1440 x 900 | Selected options, cart transition, address-error state, recovered final, original final resize, payment summary and overlay. | Same sampled states; recovered note confirmed after explicit re-entry. |

Screenshots were visually inspected for text alignment, wrapping, clipping and component occlusion. Sauce labels fit at desktop width. Cart and final-order text wrapped readably in the sampled frames. Deletion dialogs had readable text and reachable actions at all three sizes; Escape returned focus to the delete button and preserved the item.

Fixed headers and bottom buttons did not establish an additional obstruction in these samples: scrolled-under content could be brought back into view. The short payment-summary finding concerns horizontal overflow, demonstrated by both painted frames and a 360-pixel document width at a 320-pixel viewport.

The isolated payment-layout captures use one item without a coupon, so their correct total is 28,000원. They supplement, and do not replace, the two-item 48,000원 integrity checks.

## Method and limits

The run used the existing Playwright installation with owned fresh Chromium contexts, DPR 1. Only the two supplied localhost targets were navigated. Product files were not changed. No accounts, external pages, provider changes, installations, real payment or delegation were used. The user authorized synthetic fixture inputs and local evidence/report writes; design and code writes were not authorized.

Build versions and Figma source were unavailable. Captures identify the URL and time, but cannot establish version identity across deployments. Short and desktop checks used key-state replay and resizing rather than a complete independent end-to-end run at each fixed viewport. Initial desktop menu and desktop invalid-coupon rendering remain unreviewed. No post-fix replay occurred.

There was one procedural deviation: a focus probe read `BODY.textContent` when focus left the controls, unintentionally returning non-rendered script text. That content was excluded from saved focus evidence and conclusions. Reported findings rely on reproduced UI behavior, screenshots and accessible controls. Initial receipt attempts for `a-mobile-menu.png` and `a-mobile-sauce-error.png` failed; priority findings use later captures with contemporaneous receipts.

KWCAG 2.2 and WCAG 2.2 mappings are separately unconfirmed. Keyboard navigation and accessible names were inspected; official standards text and assistive-technology speech were not checked. This report makes no compliance certification.

Unsupported hypotheses are separated in `findings.json`. B's generic coupon error was observed, but correcting the code worked; measured confusion or recovery difficulty is unknown. No preference, prevalence, conversion or user-benefit claim is made.
