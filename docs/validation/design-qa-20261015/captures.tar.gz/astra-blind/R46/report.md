# Delivery UX QA

Variant A completed the requested mobile flow with all final values intact. Variant B reached a receipt for 48,000 won but silently dropped the allergy note during missing-address validation. Its final receipt explicitly shows `가게 요청 없음`. This is the most consequential reproduced failure.

Both variants produced a 25,000-won configured item and a 50,000-won cart at quantity 2. Correcting `HANKI5000` to `HANKKI5000` applied 5,000 won off; the 3,000-won delivery fee resulted in 48,000 won. Both receipts retained the requested options, bell delivery request, `302동1104호` and 동네페이. A also retained the complete allergy note.

## Findings

1. B clears the allergy note when submission fails for a missing detail address. Correcting only the address then submits an order without the note. Reproduced at mobile and short sizes. See `b-coupon-error.png`, `b-address-error.png`, `b-final-mobile.png` and `b-checkout-short-error.png`.
2. B's required part controls are unreachable by Tab. From the back button, focus jumps straight to sauce selection. The 순살 choice is exposed as a plain DIV without role or tabindex. See `dom-observations.json` and `b-options-short-keyboard.png`.
3. B rejects an add with missing sauce without displaying a reason or recovery message. Selecting sauce subsequently works. See `b-sauce-no-feedback-confirm.png`.
4. B clips sauce surcharge text at 384px and 320px. This was confirmed in actual screenshots; the desktop labels fit. See `b-missing-sauce.png`, `b-options-short-keyboard.png` and `b-options-desktop.png`.
5. B's cart minus and plus buttons have empty accessible names. Visual activation works, but accessible navigation cannot identify their actions. See `dom-observations.json` and `b-cart-two.png`.
6. B's coupon error only says the coupon cannot be applied and shows `CPN-4003`. It offers no spelling correction guidance. Applying the supplied correct code succeeds. See `b-coupon-error.png`.

## Coverage and limits

Full flows were exercised at 384x832. Menu, option keyboard traversal, cart, checkout selection/error and receipt states were visually inspected at 320x568. Options, cart, checkout error and receipt states were inspected at 1440x900. The second run switched viewports; it was not a separate end-to-end run at each size.

Screenshots were reviewed for text alignment, wrapping, clipping and fixed-header/footer overlap. Cart and receipt text remained readable in the inspected states. Scroll-under-header behavior was not counted as a defect. No additional reproduced failure was found in A within this bounded coverage; this is not an all-QA-pass claim.

Figma fidelity is unknown. Testing used an owned headless Chromium context and the installed Playwright package, with no product modification or external browsing. Physical mobile keyboards, screen-reader software and backend persistence were not tested. Unsupported hypotheses: none recorded as findings.

`findings.json` contains the structured findings, coverage and limitations. `dom-observations.json` preserves the relevant rendered-DOM and keyboard observations. All referenced screenshots are in this directory.
